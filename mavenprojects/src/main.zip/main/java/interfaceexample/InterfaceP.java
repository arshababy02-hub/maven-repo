package interfaceexample;

public interface InterfaceP {
	
	public void print();//with non abstract keyword
	
	public abstract void display(String s);//with abstract keyword

}
