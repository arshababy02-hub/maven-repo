package Inheritence;

public class MultiC extends MultiP{

	public static void main(String[] args) {
		
		MultiC obj= new MultiC();
		obj.sings();
		obj.dance();
	}

}
