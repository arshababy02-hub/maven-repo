package Inheritence;

public class MultiGP {
	public void sings() {
		System.out.println("grandfather sings");
	
	}

}
