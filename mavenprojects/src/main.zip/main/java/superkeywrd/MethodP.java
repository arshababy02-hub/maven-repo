package superkeywrd;

public class MethodP {
	public void write() {
		System.out.println("parent writes");
	}

}
