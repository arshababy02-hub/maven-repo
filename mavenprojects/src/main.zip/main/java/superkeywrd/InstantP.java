package superkeywrd;

public class InstantP {
	int ip=2005;
	

}
