package finalkeyword;

public class FinalMethodeC extends FinalMethodP {
/*public void print() {
}*/

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
