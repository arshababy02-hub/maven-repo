package Inheritence;

public class SingleP {
public void write() {
	System.out.println("parent class");
}
public void draw() {
	System.out.println("parent draws");
}
}
