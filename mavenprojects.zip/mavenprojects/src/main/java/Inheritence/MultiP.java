package Inheritence;

public class MultiP extends MultiGP {
	public void dance() {
		System.out.println("dance");
	}

}
