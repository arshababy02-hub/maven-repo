package Inheritence;

public class HeirachyP {
public void dance() {
	System.out.println("parent dance");
}
}
