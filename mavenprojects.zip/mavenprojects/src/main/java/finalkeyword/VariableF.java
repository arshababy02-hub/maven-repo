package finalkeyword;

public class VariableF {

	public static void main(String[] args) {
		final int a=10;//value of cannot be changes if final keyword used
		//a=100;
		System.out.println(final method);

	}

}
