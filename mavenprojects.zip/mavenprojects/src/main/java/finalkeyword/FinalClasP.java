package finalkeyword;

public final class FinalClasP {
	int a=10;

}
