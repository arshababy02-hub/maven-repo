package finalkeyword;

public  class FinalMethodP {
public final void print() {
	System.out.println("Final keyword");
}
}
