package encapsulation;

public class EncapC {

	public static void main(String[] args) {
		EncapP p=new EncapP();
		p.set(10, "arsha");
		p.get();

	}

}
