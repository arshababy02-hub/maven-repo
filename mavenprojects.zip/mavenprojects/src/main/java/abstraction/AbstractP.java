package abstraction;

public abstract class AbstractP {//parent cls must be abstract.methode does not contain body
	public abstract void print();//abstract methode
	public void display() {
		System.out.println("non-anstract method");
	}

}
