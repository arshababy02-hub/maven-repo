package superkeywrd;

public class ConstructorP {
	

	public  ConstructorP(int a) {
	System.out.println("parent constructor is called"+ a);
}
}