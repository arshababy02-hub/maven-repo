package assignments;

public interface RBI {
	double InterestRate=6.5;
	public void reccurringDeposit(double amount,int year);
	
	

}
